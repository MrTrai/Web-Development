<!DOCTYPE html>
<html>
    <head>
        <title>Teacher Questions</title>
        <link rel="stylesheet" href="../css/styles.css" type="text/css" />
        <?php include "qaManagement.php"?>
    </head>


    <body>


    </body>
</html>
